const { Builder, By, Key } = require('selenium-webdriver');
const { readFile } = require('fs');

const regex = /[0-9]{8}/g;

readFile('/home/ondrejsvoren/Downloads/test.txt', 'utf-8', async (err, data) => {
  if (err) throw err;
  const pmIDs = data.match(regex);

  for (const pmID of pmIDs) {
    try {
      await example(pmID);
    } catch (e) {
      console.error('ERROR: Unable to download file.');
    }
  }
});

async function example(input) {
  let driver = await new Builder().forBrowser('chrome').build();
  return new Promise(async (resolve) => {
    try {
      await driver.get('https://sci-hub.tw/');
      await driver.findElement(By.name('request')).sendKeys(input, Key.ENTER);
      await driver.findElement(By.linkText('⇣ save')).click();
      await driver.sleep(2000);
      await driver.quit();
      resolve();
    } catch (e) {
      console.error(`ERROR: Unable to find article with PMID: ${input}.`);
      resolve();
    }
  });
}
